ALIASED_TARGET
--------------

Name of target aliased by this target.

If this is an :ref:`Alias Target <Alias Targets>`, this property contains
the name of the target aliased.
