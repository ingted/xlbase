COMPILE_FLAGS
-------------

Additional flags to use when compiling this target's sources.

The COMPILE_FLAGS property sets additional compiler flags used to
build sources within the target.  Use COMPILE_DEFINITIONS to pass
additional preprocessor definitions.

This property is deprecated.  Use the COMPILE_OPTIONS property or the
target_compile_options command instead.
