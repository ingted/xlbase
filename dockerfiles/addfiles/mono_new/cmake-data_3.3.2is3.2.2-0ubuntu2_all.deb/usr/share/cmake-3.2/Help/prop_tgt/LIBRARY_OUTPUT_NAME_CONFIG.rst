LIBRARY_OUTPUT_NAME_<CONFIG>
----------------------------

Per-configuration output name for LIBRARY target files.

This is the configuration-specific version of LIBRARY_OUTPUT_NAME.
