LINK_FLAGS
----------

Additional flags to use when linking this target.

The LINK_FLAGS property can be used to add extra flags to the link
step of a target.  LINK_FLAGS_<CONFIG> will add to the configuration
<CONFIG>, for example, DEBUG, RELEASE, MINSIZEREL, RELWITHDEBINFO.
