CMAKE_CL_64
-----------

Using the 64 bit compiler from Microsoft

Set to true when using the 64 bit cl compiler from Microsoft.
