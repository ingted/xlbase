CMAKE_STATIC_LINKER_FLAGS_<CONFIG>
----------------------------------

Flags to be used when linking a static library.

Same as CMAKE_C_FLAGS_* but used by the linker when creating static
libraries.
