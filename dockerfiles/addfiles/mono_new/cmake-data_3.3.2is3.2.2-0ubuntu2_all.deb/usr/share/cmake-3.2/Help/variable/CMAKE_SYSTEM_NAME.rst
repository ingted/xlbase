CMAKE_SYSTEM_NAME
-----------------

Name of the OS CMake is building for.

This is the name of the OS on which CMake is targeting.  This variable
is the same as :variable:`CMAKE_HOST_SYSTEM_NAME` if you build for the
host system instead of the target system when cross compiling.
