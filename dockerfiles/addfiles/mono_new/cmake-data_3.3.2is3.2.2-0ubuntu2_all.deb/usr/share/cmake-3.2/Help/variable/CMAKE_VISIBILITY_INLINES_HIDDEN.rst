CMAKE_VISIBILITY_INLINES_HIDDEN
-------------------------------

Default value for VISIBILITY_INLINES_HIDDEN of targets.

This variable is used to initialize the VISIBILITY_INLINES_HIDDEN
property on all the targets.  See that target property for additional
information.
