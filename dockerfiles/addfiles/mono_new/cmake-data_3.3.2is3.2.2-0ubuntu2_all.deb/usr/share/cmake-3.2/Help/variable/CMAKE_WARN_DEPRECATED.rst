CMAKE_WARN_DEPRECATED
---------------------

Whether to issue deprecation warnings for macros and functions.

If TRUE, this can be used by macros and functions to issue deprecation
warnings.  This variable is FALSE by default.
