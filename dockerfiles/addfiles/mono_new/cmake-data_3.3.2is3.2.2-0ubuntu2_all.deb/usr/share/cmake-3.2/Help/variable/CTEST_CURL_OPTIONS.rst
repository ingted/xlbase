CTEST_CURL_OPTIONS
------------------

Specify the CTest ``CurlOptions`` setting
in a :manual:`ctest(1)` dashboard client script.
