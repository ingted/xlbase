CTEST_P4_COMMAND
----------------

Specify the CTest ``P4Command`` setting
in a :manual:`ctest(1)` dashboard client script.
