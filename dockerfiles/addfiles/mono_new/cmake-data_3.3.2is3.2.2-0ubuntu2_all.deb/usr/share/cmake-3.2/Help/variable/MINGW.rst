MINGW
-----

True when using MinGW

Set to true when the compiler is some version of MinGW.
