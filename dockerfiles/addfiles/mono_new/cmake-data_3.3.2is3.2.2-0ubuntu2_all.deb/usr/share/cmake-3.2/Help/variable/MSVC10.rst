MSVC10
------

True when using Microsoft Visual C 10.0

Set to true when the compiler is version 10.0 of Microsoft Visual C.
