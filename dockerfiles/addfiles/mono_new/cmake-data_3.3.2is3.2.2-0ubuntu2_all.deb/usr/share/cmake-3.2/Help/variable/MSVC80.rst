MSVC80
------

True when using Microsoft Visual C 8.0

Set to true when the compiler is version 8.0 of Microsoft Visual C.
