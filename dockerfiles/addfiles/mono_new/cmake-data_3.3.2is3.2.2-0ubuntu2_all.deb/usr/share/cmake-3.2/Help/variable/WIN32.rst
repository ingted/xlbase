WIN32
-----

True on windows systems, including win64.

Set to true when the target system is Windows.
