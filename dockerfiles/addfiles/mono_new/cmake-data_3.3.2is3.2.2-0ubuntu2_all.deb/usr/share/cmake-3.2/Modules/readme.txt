See the "Find Modules" section of the cmake-developer(7) manual page.

For more information about how to contribute modules to CMake, see this page:
http://www.cmake.org/Wiki/CMake:Module_Maintainers
