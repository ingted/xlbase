require 'rubygems'
require 'test/unit'

require 'test_cfgsync.rb'
require 'test_config.rb'
require 'test_corosyncconf.rb'
