exec sql define REGRESSDB1 regress1;
exec sql define REGRESSDB2 connectdb;

exec sql define REGRESSUSER1 regressuser1;
exec sql define REGRESSUSER2 regressuser2;
