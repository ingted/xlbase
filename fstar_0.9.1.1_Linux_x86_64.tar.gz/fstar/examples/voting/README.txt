These examples are taken from the article "Type-Based Verification of
Electronic Voting Protocols" by V. Cortier, F. Eigner, S. Kremer, M.
Maffei and C. Wiedling.

The original version is using rF* to prove privacy properties on a
voting protocol <https://sps.cs.uni-saarland.de/voting>. Here is a
translation into the current version of F*, using the STATE2 monad.
