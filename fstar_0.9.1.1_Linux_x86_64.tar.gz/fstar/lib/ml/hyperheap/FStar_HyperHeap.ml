type rid = unit
type ('a, 'b) rref = 'b ref
let root = []

