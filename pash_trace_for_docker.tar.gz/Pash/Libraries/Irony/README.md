The official Irony has language samples, a grammar explorer, and other stuff that I didn't include here. We only need the parsing engine. The rest can be found at http://irony.codeplex.com
