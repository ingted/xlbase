﻿using System;

namespace Microsoft.PowerShell.Commands
{
    public enum TestPathType
    {
        Any,
        Container,
        Leaf
    }
}

