using System;

namespace System.Management.Automation
{
    public abstract class FlowControlException : SystemException
    {
    }
}

