﻿// Copyright (C) Pash Contributors. License: GPL/BSD. See https://github.com/Pash-Project/Pash/
using System;

namespace System.Management.Automation.Host
{
    public enum BufferCellType
    {
        Complete = 0,
        Leading = 1,
        Trailing = 2,
    }
}
