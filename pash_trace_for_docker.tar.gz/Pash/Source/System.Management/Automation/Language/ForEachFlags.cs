﻿// Copyright (C) Pash Contributors. License: GPL/BSD. See https://github.com/Pash-Project/Pash/
using System;

namespace System.Management.Automation.Language
{
    [Flags]
    public enum ForEachFlags
    {
        None = 0,
        Parallel = 1,
    }
}
