﻿using System;

namespace System.Management.Automation
{
    public enum ModuleAccessMode
    {
        ReadWrite,
        ReadOnly,
        Constant
    }
}

