﻿using System;

namespace System.Management.Automation
{
    public enum ModuleType
    {
        Binary,
        Cim,
        Manifest,
        Script,
        Workflow
    }
}

