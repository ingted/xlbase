﻿// Copyright (C) Pash Contributors. License GPL/BSD. See https://github.com/Pash-Project/Pash/
using System;
using System.Collections.Generic;
using System.Text;

namespace System.Management.Automation
{
    public sealed class ProxyCommand
    {
        public static string Create(CommandMetadata commandMetadata)
        {
            throw new NotImplementedException();
        }

        public static string Create(CommandMetadata commandMetadata, string helpComment)
        {
            throw new NotImplementedException();
        }

        public static string GetCmdletBindingAttribute(CommandMetadata commandMetadata)
        {
            throw new NotImplementedException();
        }

        public static string GetParamBlock(CommandMetadata commandMetadata)
        {
            throw new NotImplementedException();
        }

        public static string GetBegin(CommandMetadata commandMetadata)
        {
            throw new NotImplementedException();
        }

        public static string GetProcess(CommandMetadata commandMetadata)
        {
            throw new NotImplementedException();
        }

        public static string GetEnd(CommandMetadata commandMetadata)
        {
            throw new NotImplementedException();
        }

        public static string GetHelpComments(PSObject help)
        {
            throw new NotImplementedException();
        }
    }
}
