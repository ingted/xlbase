﻿// Copyright (C) Pash Contributors. License: GPL/BSD. See https://github.com/Pash-Project/Pash/

namespace System.Management.Automation
{
    /// <summary>
    /// Other verbs not used anywhere else.
    /// </summary>
    public static class VerbsOther
    {
        public const string Use = "Use";
    }
}