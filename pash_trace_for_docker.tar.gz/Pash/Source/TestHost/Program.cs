﻿// Copyright (C) Pash Contributors. License: GPL/BSD. See https://github.com/Pash-Project/Pash/
using System;

namespace TestHost
{
    class Program
    {
        static void Main(string[] args)
        {
            // I'd like to see this run NUnit, so we can debug these tests easilly.
            throw new NotImplementedException();
        }
    }
}
